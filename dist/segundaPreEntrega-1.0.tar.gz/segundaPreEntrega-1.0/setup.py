from setuptools import setup

setup(name="segundaPreEntrega", version="1.0", description="Segunda Pre Entrega", author="Maria Ayelen Ueki")